a= "Hola Mundo!"
print(a)